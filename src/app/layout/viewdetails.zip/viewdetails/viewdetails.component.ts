import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdetails',
  templateUrl: './viewdetails.component.html',
  styleUrls: ['./viewdetails.component.scss']
})
export class ViewdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
