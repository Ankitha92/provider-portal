import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-claimstatus',
  templateUrl: './claimstatus.component.html',
  styleUrls: ['./claimstatus.component.scss']
})
export class ClaimstatusComponent implements OnInit {

  show :boolean=false;
  form = new FormGroup({
    claimid: new FormControl('',[Validators.required])
  });
  constructor() { }
  ngOnInit(): void {
  }
 
  get f() {
    return this.form.controls;
  }
  showTable(){
    this.show=true;
    console.log(this.show)
  }

}
